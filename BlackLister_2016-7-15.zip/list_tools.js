
function ID(idName) {
    return document.getElementById(idName);
}



///---------Include list_tools.js------------------------------
function Link(url)  {
   this.url = url;
   this.hits = 0;
}


function findMatchingLink(url, list) {
    var target = findMatchingLinkIndex(url, list);
    if(target != -1)  {  return list[target];  }
    else return null;
}   

function findMatchingLinkIndex(url, list) {
    if(list == null)  { return -1; }
    
    for (var i = 0; i < list.length; i++)  {
        if(checkUrlForListItem(url, list[i].url) == true) {
            return i;  
        }
    }   
    return -1;
} 

function checkUrlForListItem(url, itemText) {
    var target_index = url.indexOf(itemText);

    //if the list url is found in this link
    if(target_index != -1) {

        //if it begins the link, good
        if(target_index == 0)
            return true;

        //if it is not prepended by a letter, character, or dash, it's not part of the domain name, good
        else {
            var prev_char = url.charAt(target_index - 1);
            var matches = prev_char.match(/[\w\n-]/g);
            if(matches == null)
                return true;
        }
    }  

    return false;
}


function removeMatchingLink(url, list) {
    var target = findMatchingLinkIndex(url, list);
    if(target != -1)  {  list.splice(target, 1);   return true;  }
    return false;
}  
///---------------------------------------------------------------




