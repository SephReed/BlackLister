







var black_domNode = ID("the_black_list");
var a_domNode = ID("the_a_list");

var black_btn = ID("black_list_btn");
var a_btn = ID("a_list_btn");

var blam_addBtn = ID("blam_add_item");
var a_addBtn = ID("highlight_add_item");

var blam_addText = ID('blam_add_me');
var a_addText = ID('highlight_add_me');


window.onload = function(e){ 


    black_btn.addEventListener("click", function() {
    	black_btn.classList.add("button_on");
    	a_btn.classList.remove("button_on");

    	black_domNode.style.display = "block";
    	a_domNode.style.display = "none";
    });



    a_btn.addEventListener("click", function() {
    	a_btn.classList.add("button_on");
    	black_btn.classList.remove("button_on");

    	a_domNode.style.display = "block";
    	black_domNode.style.display = "none";
    });



    blam_addText.onkeypress=function(e){
	    if(e.keyCode==13) blam_addBtn.click();
	}

	
	blam_addBtn.addEventListener("click", function()  {
			//
		var url = blam_addText.value;
		if(!url || !url.length)
			return;

		var link = new Link(url);  
        black_list.push(link);

		chrome.storage.local.set({ 'black_list' : black_list  }, function() {}); 

		addItem(url, black_list);
	});

	a_addText.onkeypress=function(e){
	    if(e.keyCode==13) a_addBtn.click();
	}

	
	a_addBtn.addEventListener("click", function()  {	
		console.log("GO")
			//
		var url = a_addText.value;
		console.log("HERE1", url);
		if(!url || !url.length)
			return;

		console.log("HERE2");
		var link = new Link(url);  
		console.log("HERE3", a_list);
        a_list.push(link);

        
        console.log("HERE4");

		chrome.storage.local.set({ 'a_list' : a_list  }, function() {}); 



		addItem(url, a_list);
	});
}








var black_list;
chrome.storage.local.get('black_list', function(result)  {
	black_list = result.black_list || [];
	console.log("BLACK_LIST", black_list)
	displayList(black_list);
});


var a_list;
chrome.storage.local.get('a_list', function(result)  {

	a_list = result.a_list || [];
	console.log("A_LIST", a_list)
	displayList(a_list);
});



function displayList(list)  {
	for(var i = 0; i < list.length; i++)  {
		var url = list[i].url;
		addItem(url, list);
	}
}







function addItem(url, list) {

	var listItem = document.createElement("DIV");
	listItem.name = url;
	listItem.classList.add("list_item");

	var button = document.createElement("BUTTON");
	button.textContent = "x";
	button.name = url;
	button.className = "unblock_item";

	listItem.appendChild(button);

	var span = document.createElement("SPAN");
	span.textContent = url;

	if(list == a_list)  {
		span.classList.add("good_link");  }

	listItem.appendChild(span);

	console.log("addItem", a_addText);

	if(list == black_list) {
		blam_addText.parentNode.insertBefore(listItem, blam_addText.nextSibling);  }
	else if(list == a_list) {
		console.log(a_addText);
		a_addText.parentNode.insertBefore(listItem, a_addText.nextSibling);  }

	var buttons = listItem.getElementsByTagName("BUTTON");
	buttons[0].addEventListener("click", function() {
		var link = this.name;

		console.log(link);

		removeMatchingLink(link, list); 	
		if(list == black_list) {
			chrome.storage.local.set({ 'black_list' : list  }, function() {});  }
		if(list == a_list) {
			chrome.storage.local.set({ 'a_list' : list  }, function() {});  }

        var container = this.parentNode;
        container.parentNode.removeChild(container);
    
	});
}


















