# Black-Lister
Black list sites you hate

Seriously, it's a super basic function, it should be built in to search engines already.  Don't like about.com?  Me either.  Think w3 anything is waste of data?  Blam it.
